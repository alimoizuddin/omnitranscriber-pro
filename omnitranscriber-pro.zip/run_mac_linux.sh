#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/backend"

PY_CMD=""
if command -v python3.11 >/dev/null 2>&1; then
  PY_CMD="python3.11"
elif command -v python3.10 >/dev/null 2>&1; then
  PY_CMD="python3.10"
elif command -v python3 >/dev/null 2>&1 && python3 -c 'import sys; raise SystemExit(0 if (3, 10) <= sys.version_info[:2] < (3, 13) else 1)'; then
  PY_CMD="python3"
fi

if [ -z "$PY_CMD" ]; then
  echo "Python 3.10 or 3.11 was not found. Install Python 3.11, then run this file again."
  exit 1
fi

if ! command -v ffmpeg >/dev/null 2>&1; then
  echo "FFmpeg was not found. The app can still open, but audio/video cleaning may not work."
  echo "Install FFmpeg later for best results."
fi

if [ ! -x ".venv/bin/python" ]; then
  echo "Creating the app environment..."
  "$PY_CMD" -m venv .venv
fi

. ".venv/bin/activate"
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

if command -v xdg-open >/dev/null 2>&1; then
  xdg-open "http://127.0.0.1:8000" >/dev/null 2>&1 || true
elif command -v open >/dev/null 2>&1; then
  open "http://127.0.0.1:8000" >/dev/null 2>&1 || true
fi

python app.py
