from __future__ import annotations

import json
from pathlib import Path

from ..utils import ensure_dir, zip_dir


def _srt_ts(t: float) -> str:
    h = int(t // 3600)
    m = int((t % 3600) // 60)
    s = int(t % 60)
    ms = int((t - int(t)) * 1000)
    return f'{h:02d}:{m:02d}:{s:02d},{ms:03d}'


def _vtt_ts(t: float) -> str:
    return _srt_ts(t).replace(',', '.')


def render_plain(segments: list[dict]) -> str:
    return '\n'.join(seg['text'].strip() for seg in segments if seg['text'].strip()).strip()


def render_markdown(segments: list[dict]) -> str:
    lines = ['# Transcript', '']
    for seg in segments:
        speaker = seg.get('speaker') or 'Speaker'
        lines.append(f"- **{speaker}** `{_vtt_ts(seg['start'])}`: {seg['text'].strip()}")
    return '\n'.join(lines).strip() + '\n'


def write_outputs(job_dir: Path, base_name: str, segments: list[dict], metadata: dict) -> list[Path]:
    out_dir = ensure_dir(job_dir / 'outputs')
    paths: list[Path] = []

    txt = out_dir / f'{base_name}.txt'
    txt.write_text(render_plain(segments), encoding='utf-8')
    paths.append(txt)

    md = out_dir / f'{base_name}.md'
    md.write_text(render_markdown(segments), encoding='utf-8')
    paths.append(md)

    srt = out_dir / f'{base_name}.srt'
    lines = []
    for i, seg in enumerate(segments, start=1):
        lines += [str(i), f"{_srt_ts(seg['start'])} --> {_srt_ts(seg['end'])}", seg['text'].strip(), '']
    srt.write_text('\n'.join(lines), encoding='utf-8')
    paths.append(srt)

    vtt = out_dir / f'{base_name}.vtt'
    lines = ['WEBVTT', '']
    for seg in segments:
        lines += [f"{_vtt_ts(seg['start'])} --> {_vtt_ts(seg['end'])}", seg['text'].strip(), '']
    vtt.write_text('\n'.join(lines), encoding='utf-8')
    paths.append(vtt)

    json_path = out_dir / f'{base_name}.json'
    json_path.write_text(json.dumps({'metadata': metadata, 'segments': segments}, ensure_ascii=False, indent=2), encoding='utf-8')
    paths.append(json_path)
    return paths


def write_bundle(job_dir: Path) -> Path:
    bundle = job_dir / 'outputs_bundle.zip'
    zip_dir(job_dir / 'outputs', bundle)
    return bundle
