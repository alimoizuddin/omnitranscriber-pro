@echo off
setlocal
cd /d "%~dp0backend"

set "PY_CMD="
py -3.11 -c "import sys" >nul 2>nul
if not errorlevel 1 set "PY_CMD=py -3.11"
if not defined PY_CMD (
  py -3.10 -c "import sys" >nul 2>nul
  if not errorlevel 1 set "PY_CMD=py -3.10"
)
if not defined PY_CMD (
  python -c "import sys; raise SystemExit(0 if (3, 10) <= sys.version_info[:2] < (3, 13) else 1)" >nul 2>nul
  if not errorlevel 1 set "PY_CMD=python"
)

if not defined PY_CMD (
  echo Python 3.10 or 3.11 was not found. Install Python 3.11, then run this file again.
  pause
  exit /b 1
)

where ffmpeg >nul 2>nul
if errorlevel 1 (
  echo FFmpeg was not found. The app can still open, but audio/video cleaning may not work.
  echo Install FFmpeg later for best results.
)

if not exist ".venv\Scripts\python.exe" (
  echo Creating the app environment...
  %PY_CMD% -m venv .venv
)

call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

start "" "http://127.0.0.1:8000"
python app.py
pause
