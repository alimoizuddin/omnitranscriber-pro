from __future__ import annotations

import os
import shutil
import sys
import time
from pathlib import Path

import gradio as gr

# Determine the absolute path to the backend directory relative to this file.
ROOT = Path(__file__).resolve().parent / 'backend'
# Ensure the backend package is discoverable on the Python path.  Without this,
# running the notebook from an arbitrary location (for example, in Colab) can
# result in import failures like "No module named app".  We append rather
# than prepend to allow user‑installed packages to take precedence when
# appropriate.
sys.path.append(str(ROOT))
# Change the working directory to backend so that relative file operations (such
# as reading templates and static assets) continue to work as expected.
os.chdir(ROOT)

from app.config import settings
from app.schemas import JobOptions
from app.services.jobs import JobManager, MediaItem
from app.utils import MEDIA_EXTS, safe_name, utc_iso

manager = JobManager()


def runtime_info() -> str:
    try:
        import torch
        if torch.cuda.is_available():
            return f"CUDA available: True\nGPU: {torch.cuda.get_device_name(0)}"
    except Exception:
        pass
    return 'CUDA available: False'


def stage_files(files):
    batch_dir = settings.uploads_dir / f'colab-{utc_iso().replace(":", "-")}'
    batch_dir.mkdir(parents=True, exist_ok=True)
    items = []
    for file in files or []:
        src = Path(getattr(file, 'name', file))
        if src.suffix.lower() not in MEDIA_EXTS:
            raise gr.Error(f'Unsupported file type: {src.name}')
        dest = batch_dir / f'{safe_name(src.stem)}{src.suffix.lower()}'
        shutil.copy2(src, dest)
        items.append(MediaItem('upload', src.name, dest, dest.stem))
    return items


def submit_upload(files, prompt, glossary, diarization, model, language_hint, translation_enabled, translation_target, save_to_drive):
    """
    Submit a transcription job from the Colab UI.

    Parameters
    ----------
    files : list
        The uploaded media files.
    prompt : str
        A custom prompt string passed through to whisper.
    glossary : str
        Glossary rules (one per line, "src => dst").
    diarization : bool
        Whether to enable speaker diarization.
    model : str
        Name of the whisper model to use.
    language_hint : str
        Optional hint for the spoken language (e.g. "en" or "hi").
    translation_enabled : bool
        Enable translation of the transcript.
    translation_target : str
        Target language code (e.g. "en", "es").
    save_to_drive : bool
        If true, copy the output bundle to a configured Google Drive folder when available.
    """
    if not files:
        raise gr.Error('Upload at least one file.')
    # Build JobOptions with all user‑visible parameters.  Unspecified
    # parameters fall back to their defaults defined in schemas.py.
    opts = JobOptions(
        model=model,
        prompt=prompt or '',
        glossary_text=glossary or '',
        diarization_enabled=bool(diarization),
        language=(language_hint or None),
        translation_enabled=bool(translation_enabled),
        translation_target_language=translation_target or 'en',
        upload_to_drive=bool(save_to_drive),
    )
    job = manager.create_upload_job(stage_files(files), opts)
    # Poll job status until completion
    while True:
        detail = manager.get(job.job_id)
        if detail.status in {'completed', 'failed', 'cancelled'}:
            links = '\n'.join(a.path for a in detail.artifacts)
            return detail.preview_text or '', links, detail.status
        time.sleep(2)


def submit_url_job(urls, prompt, glossary, diarization, model, language_hint, translation_enabled, translation_target, save_to_drive):
    """
    Submit a URL transcription job from the Colab UI.

    Parameters are analogous to submit_upload().  The `urls` parameter should be
    a newline‑separated string of URLs.  Each URL will be downloaded via
    yt‑dlp and transcribed as a separate source.  All other options are
    identical.
    """
    # Parse URLs from the textarea (one per line)
    url_list = [u.strip() for u in (urls or '').splitlines() if u.strip()]
    if not url_list:
        raise gr.Error('Enter at least one URL.')
    opts = JobOptions(
        model=model,
        prompt=prompt or '',
        glossary_text=glossary or '',
        diarization_enabled=bool(diarization),
        language=(language_hint or None),
        translation_enabled=bool(translation_enabled),
        translation_target_language=translation_target or 'en',
        upload_to_drive=bool(save_to_drive),
    )
    job = manager.create_url_job(url_list, opts)
    while True:
        detail = manager.get(job.job_id)
        if detail.status in {'completed', 'failed', 'cancelled'}:
            links = '\n'.join(a.path for a in detail.artifacts)
            return detail.preview_text or '', links, detail.status
        time.sleep(2)


with gr.Blocks(title='OmniTranscriber Pro Colab') as demo:
    gr.Markdown('# OmniTranscriber Pro - Colab GPU')
    gr.Markdown(runtime_info())
    files = gr.Files(label='Upload audio/video', file_count='multiple')
    # Whisper model selection.  Includes all models supported by the backend config.
    model = gr.Dropdown(['small', 'medium', 'large-v3', 'distil-large-v3'], value='large-v3', label='Model')
    # Optional language hint.  Leave blank to auto‑detect.
    language_hint = gr.Textbox(label='Language hint (ISO‑639‑1, optional)', lines=1)
    # Prompt and glossary configuration.
    prompt = gr.Textbox(label='Prompt', lines=3)
    glossary = gr.Textbox(label='Glossary rules', lines=4, placeholder='src => dst')
    # Diarization toggle.
    diarization = gr.Checkbox(label='Enable diarization', value=False)
    # Translation options.  Selecting enable will translate the transcript into the target language.
    translation_enabled = gr.Checkbox(label='Enable translation', value=False)
    translation_target = gr.Dropdown([
        ('English', 'en'),
        ('Spanish', 'es'),
        ('French', 'fr'),
        ('German', 'de'),
        ('Hindi', 'hi'),
        ('Chinese (Simplified)', 'zh'),
        ('Japanese', 'ja'),
        ('Bengali', 'bn'),
        ('Portuguese', 'pt'),
        ('Russian', 'ru'),
    ], value='en', label='Target language')
    # Drive saving toggle. This copies the output bundle when a Drive folder is available.
    save_to_drive = gr.Checkbox(label='Save outputs to Google Drive', value=False)
    # URL job textarea and button
    urls = gr.Textbox(label='URLs (one per line)', lines=4)
    # Buttons for file upload and URL jobs
    btn_upload = gr.Button('Run upload job')
    btn_url = gr.Button('Run URL job')
    transcript = gr.Textbox(label='Preview', lines=12)
    artifacts = gr.Textbox(label='Artifacts (relative paths)', lines=8)
    status = gr.Textbox(label='Status')
    # Bind buttons to their respective functions
    btn_upload.click(
        submit_upload,
        [files, prompt, glossary, diarization, model, language_hint, translation_enabled, translation_target, save_to_drive],
        [transcript, artifacts, status],
    )
    btn_url.click(
        submit_url_job,
        [urls, prompt, glossary, diarization, model, language_hint, translation_enabled, translation_target, save_to_drive],
        [transcript, artifacts, status],
    )


demo.launch(share=True)
