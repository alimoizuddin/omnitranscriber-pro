# OmniTranscriber Pro Backend

FastAPI backend for the OmniTranscriber Pro browser app.

## Start

```bash
python -m pip install -r requirements.txt
python app.py
```

The frontend is served from the project-level `frontend/` folder.

## Useful Endpoints

- `GET /` - browser app
- `GET /api/health` - startup check
- `GET /api/system` - FFmpeg, yt-dlp, and GPU readiness
- `POST /api/jobs/upload` - upload audio/video files
- `POST /api/jobs/url` - queue link downloads and transcription
- `GET /api/jobs` - job list
- `GET /api/jobs/{job_id}` - job detail
- `GET /api/download/{path}` - safe download for generated files

## Notes

Heavy ML libraries are imported only when a transcription job runs, so the web app can boot before models are downloaded. Speaker diarization requires `OT_HF_TOKEN`.
