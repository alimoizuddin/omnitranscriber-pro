from __future__ import annotations

import json
import re
import shutil
import uuid
from datetime import datetime, timezone
from pathlib import Path

MEDIA_EXTS = {
    '.mp3', '.wav', '.m4a', '.flac', '.ogg', '.mp4', '.mkv', '.avi', '.mov', '.webm', '.aac'
}


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def utc_iso() -> str:
    return utc_now().isoformat()


def safe_name(text: str) -> str:
    cleaned = re.sub(r'[^A-Za-z0-9._-]+', '-', text).strip('-_.')
    return cleaned or f'item-{uuid.uuid4().hex[:8]}'


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def write_json(path: Path, data: dict | list) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')


def read_json(path: Path, default):
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding='utf-8'))


def zip_dir(source: Path, dest_zip: Path) -> None:
    base_name = str(dest_zip.with_suffix(''))
    archive = shutil.make_archive(base_name, 'zip', source)
    if Path(archive) != dest_zip:
        Path(archive).replace(dest_zip)


def parse_glossary(text: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith('#'):
            continue
        if '=>' in line:
            src, dst = line.split('=>', 1)
        elif '=' in line:
            src, dst = line.split('=', 1)
        else:
            continue
        out[src.strip()] = dst.strip()
    return out


def apply_glossary(text: str, glossary: dict[str, str]) -> str:
    updated = text
    for src, dst in glossary.items():
        updated = re.sub(rf'\b{re.escape(src)}\b', dst, updated, flags=re.IGNORECASE)
    return updated
