from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field


class JobOptions(BaseModel):
    model: str = 'large-v3'
    language: str | None = None
    prompt: str = ''
    include_domain_prompt: bool = True
    device: str = 'auto'
    compute_type: str = 'auto'
    preprocess_audio: bool = True
    vad_filter: bool = True
    diarization_enabled: bool = False
    diarization_min_speakers: int | None = None
    diarization_max_speakers: int | None = None
    chunk_minutes: int = 20
    chunk_overlap_seconds: int = 5
    translation_enabled: bool = False
    translation_target_language: str = 'en'
    source_mode: str = 'transcribe'
    enable_word_timestamps: bool = True
    confidence_threshold: float = 0.45
    glossary_text: str = ''
    upload_to_drive: bool = False


class UrlIngestRequest(BaseModel):
    urls: list[str]
    options: JobOptions = Field(default_factory=JobOptions)


class SegmentPatch(BaseModel):
    id: str
    text: str
    speaker: str | None = None


class SegmentView(BaseModel):
    id: str
    start: float
    end: float
    text: str
    speaker: str | None = None
    avg_logprob: float | None = None
    confidence: float | None = None
    low_confidence: bool = False
    words: list[dict] = Field(default_factory=list)
    language: str | None = None


class ArtifactView(BaseModel):
    name: str
    path: str
    size_bytes: int
    kind: str


class JobSummary(BaseModel):
    job_id: str
    title: str
    status: Literal['queued', 'running', 'completed', 'failed', 'cancelled']
    progress: float = 0.0
    message: str = ''
    created_at: datetime
    updated_at: datetime
    source_count: int = 0
    outputs_zip: str | None = None
    preview_text: str = ''
    errors: list[str] = Field(default_factory=list)


class JobDetail(JobSummary):
    options: JobOptions
    segments: list[SegmentView] = Field(default_factory=list)
    artifacts: list[ArtifactView] = Field(default_factory=list)
    glossary: dict[str, str] = Field(default_factory=dict)
    metrics: dict = Field(default_factory=dict)
