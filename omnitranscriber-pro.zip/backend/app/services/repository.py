from __future__ import annotations

import json
from datetime import datetime

from ..db import get_db
from ..schemas import ArtifactView, JobDetail, JobOptions, JobSummary, SegmentView


def _parse_dt(value: str) -> datetime:
    return datetime.fromisoformat(value)


class Repository:
    def __init__(self):
        self.db = get_db()

    def insert_job(self, job_id: str, title: str, options: JobOptions, source_count: int, created_at: str):
        self.db.execute(
            '''INSERT INTO jobs(job_id,title,status,progress,message,created_at,updated_at,options_json,source_count,errors_json,metrics_json,glossary_json)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''',
            (job_id, title, 'queued', 0.0, 'Queued', created_at, created_at, options.model_dump_json(), source_count, '[]', '{}', '{}')
        )

    def update_job(self, job_id: str, **kwargs):
        if not kwargs:
            return
        parts = []
        values = []
        for k, v in kwargs.items():
            parts.append(f'{k}=?')
            if isinstance(v, (dict, list)):
                values.append(json.dumps(v, ensure_ascii=False))
            else:
                values.append(v)
        sql = f"UPDATE jobs SET {', '.join(parts)} WHERE job_id=?"
        values.append(job_id)
        self.db.execute(sql, tuple(values))

    def replace_segments(self, job_id: str, segments: list[dict]):
        """Replace all segments for a job.

        The incoming segment dicts may contain a 'language' key which is stored in
        the segments table.  If absent the language column will be NULL.
        """
        self.db.execute('DELETE FROM segments WHERE job_id=?', (job_id,))
        rows = []
        for seg in segments:
            rows.append((
                seg['id'],
                job_id,
                seg['start'],
                seg['end'],
                seg['text'],
                seg.get('speaker'),
                seg.get('avg_logprob'),
                seg.get('confidence'),
                1 if seg.get('low_confidence') else 0,
                json.dumps(seg.get('words', []), ensure_ascii=False),
                seg.get('language'),
            ))
        self.db.executemany(
            '''INSERT INTO segments(id,job_id,start,end,text,speaker,avg_logprob,confidence,low_confidence,words_json,language)
               VALUES(?,?,?,?,?,?,?,?,?,?,?)''',
            rows,
        )

    def replace_artifacts(self, job_id: str, artifacts: list[dict]):
        self.db.execute('DELETE FROM artifacts WHERE job_id=?', (job_id,))
        rows = [(job_id, a['name'], a['path'], a['size_bytes'], a['kind']) for a in artifacts]
        self.db.executemany('INSERT INTO artifacts(job_id,name,path,size_bytes,kind) VALUES(?,?,?,?,?)', rows)

    def list_jobs(self) -> list[JobSummary]:
        rows = self.db.query('SELECT * FROM jobs ORDER BY created_at DESC')
        return [self._row_to_summary(r) for r in rows]

    def get_job(self, job_id: str) -> JobDetail:
        jobs = self.db.query('SELECT * FROM jobs WHERE job_id=?', (job_id,))
        if not jobs:
            raise KeyError(job_id)
        row = jobs[0]
        seg_rows = self.db.query('SELECT * FROM segments WHERE job_id=? ORDER BY start ASC', (job_id,))
        art_rows = self.db.query('SELECT * FROM artifacts WHERE job_id=? ORDER BY id ASC', (job_id,))
        return JobDetail(
            **self._row_to_summary(row).model_dump(),
            options=JobOptions.model_validate_json(row['options_json']),
            segments=[
                SegmentView(
                    id=s['id'],
                    start=s['start'],
                    end=s['end'],
                    text=s['text'],
                    speaker=s['speaker'],
                    avg_logprob=s['avg_logprob'],
                    confidence=s['confidence'],
                    low_confidence=bool(s['low_confidence']),
                    words=json.loads(s['words_json']),
                    language=s['language'],
                )
                for s in seg_rows
            ],
            artifacts=[ArtifactView(name=a['name'], path=a['path'], size_bytes=a['size_bytes'], kind=a['kind']) for a in art_rows],
            glossary=json.loads(row['glossary_json']),
            metrics=json.loads(row['metrics_json']),
        )

    def _row_to_summary(self, row) -> JobSummary:
        return JobSummary(
            job_id=row['job_id'],
            title=row['title'],
            status=row['status'],
            progress=row['progress'],
            message=row['message'],
            created_at=_parse_dt(row['created_at']),
            updated_at=_parse_dt(row['updated_at']),
            source_count=row['source_count'],
            outputs_zip=row['outputs_zip'],
            preview_text=row['preview_text'],
            errors=json.loads(row['errors_json']),
        )
