from __future__ import annotations

import logging
import os
import shutil
from pathlib import Path


def _drive_destination() -> Path | None:
    configured = os.getenv('OT_GOOGLE_DRIVE_DIR')
    if configured:
        return Path(configured).expanduser()

    colab_drive = Path('/content/drive/MyDrive')
    if colab_drive.exists():
        return colab_drive / 'OmniTranscriber'

    return None


def upload_bundle_to_drive(bundle: Path, job_id: str) -> None:
    destination = _drive_destination()
    if destination is None:
        logging.info(
            'Job %s requested Google Drive saving, but no Drive folder is available. '
            'In Colab, mount Google Drive first. Locally, set OT_GOOGLE_DRIVE_DIR.',
            job_id,
        )
        return

    destination.mkdir(parents=True, exist_ok=True)
    target = destination / f'omni_transcriber_{job_id}.zip'
    shutil.copy2(bundle, target)
    logging.info('Saved job %s bundle to %s', job_id, target)
