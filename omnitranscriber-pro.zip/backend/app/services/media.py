from __future__ import annotations

import shutil
import subprocess
from pathlib import Path
from urllib.parse import unquote, urlparse

from ..utils import MEDIA_EXTS, ensure_dir, safe_name


def has_binary(name: str) -> bool:
    return shutil.which(name) is not None


def download_url(url: str, output_dir: Path) -> Path:
    ensure_dir(output_dir)
    suffix = Path(unquote(urlparse(url).path)).suffix.lower()
    if suffix in MEDIA_EXTS:
        return download_direct_media(url, output_dir)

    before = {p.resolve() for p in output_dir.iterdir() if p.is_file()}
    if has_binary('yt-dlp'):
        template = str(output_dir / '%(title).120s-%(id)s.%(ext)s')
        cmd = ['yt-dlp', '-o', template, '-f', 'bestaudio/best', '--no-playlist', url]
        try:
            subprocess.run(cmd, check=True)
            new_files = [p for p in output_dir.iterdir() if p.is_file() and p.resolve() not in before]
            if new_files:
                return max(new_files, key=lambda p: p.stat().st_mtime)
        except subprocess.CalledProcessError:
            pass
    return download_direct_media(url, output_dir)


def download_direct_media(url: str, output_dir: Path) -> Path:
    import requests

    parsed = urlparse(url)
    name = safe_name(Path(unquote(parsed.path)).stem or parsed.netloc or 'download')
    suffix = Path(unquote(parsed.path)).suffix.lower() or '.media'
    dest = output_dir / f'{name}{suffix}'
    headers = {
        'User-Agent': 'OmniTranscriber/2.0',
        'bypass-tunnel-reminder': 'true',
    }
    with requests.get(url, stream=True, timeout=60, headers=headers) as response:
        response.raise_for_status()
        with dest.open('wb') as handle:
            for chunk in response.iter_content(chunk_size=1024 * 1024):
                if chunk:
                    handle.write(chunk)
    if dest.stat().st_size == 0:
        raise RuntimeError(f'Downloaded an empty file from {url}')
    return dest


def preprocess_media(src: Path, dest_dir: Path) -> Path:
    ensure_dir(dest_dir)
    out = dest_dir / f'{safe_name(src.stem)}-mono16k.wav'
    if not has_binary('ffmpeg'):
        return src
    cmd = [
        'ffmpeg', '-y', '-i', str(src), '-ac', '1', '-ar', '16000', '-vn',
        '-af', 'loudnorm=I=-16:TP=-1.5:LRA=11', str(out)
    ]
    subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return out
