from __future__ import annotations

import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

from ..config import settings
from ..schemas import JobDetail, JobOptions
from ..utils import ensure_dir, parse_glossary, safe_name, utc_iso
from .diarization import assign_speakers, diarize
from .exporter import render_plain, write_bundle, write_outputs
from .media import download_url, preprocess_media
from .repository import Repository
from .transcription import transcribe


@dataclass
class MediaItem:
    source_type: str
    source_value: str
    local_path: Path
    display_name: str


class JobManager:
    def __init__(self):
        self.repo = Repository()
        self.executor = ThreadPoolExecutor(max_workers=settings.max_workers)
        self.cancelled: set[str] = set()
        self.lock = threading.Lock()
        self.runtime_items: dict[str, list[MediaItem]] = {}

    def list_jobs(self):
        return self.repo.list_jobs()

    def get(self, job_id: str) -> JobDetail:
        return self.repo.get_job(job_id)

    def cancel(self, job_id: str) -> None:
        with self.lock:
            self.cancelled.add(job_id)
        self.repo.update_job(job_id, status='cancelled', message='Cancelled', updated_at=utc_iso())

    def create_upload_job(self, items: list[MediaItem], options: JobOptions):
        title = items[0].display_name if len(items) == 1 else f'Batch job ({len(items)} files)'
        job_id = uuid.uuid4().hex[:12]
        created_at = utc_iso()
        self.repo.insert_job(job_id, title, options, len(items), created_at)
        self.runtime_items[job_id] = items
        self.executor.submit(self._run_job, job_id, options)
        return self.repo.get_job(job_id)

    def create_url_job(self, urls: list[str], options: JobOptions):
        job_id = uuid.uuid4().hex[:12]
        created_at = utc_iso()
        title = urls[0] if len(urls) == 1 else f'URL batch ({len(urls)} links)'
        self.repo.insert_job(job_id, title, options, len(urls), created_at)
        items = [
            MediaItem(
                source_type='url',
                source_value=url,
                local_path=Path(),
                display_name=safe_name(urlparse(url).netloc or 'url'),
            )
            for url in urls
        ]
        self.runtime_items[job_id] = items
        self.executor.submit(self._run_job, job_id, options)
        return self.repo.get_job(job_id)

    def save_segments(self, job_id: str, patches: list[dict]):
        job = self.repo.get_job(job_id)
        mapping = {seg.id: seg.model_dump() for seg in job.segments}
        for patch in patches:
            item = mapping[patch['id']]
            item['text'] = patch['text']
            if patch.get('speaker') is not None:
                item['speaker'] = patch['speaker']
        merged = list(mapping.values())
        self.repo.replace_segments(job_id, merged)
        job_dir = settings.jobs_dir / job_id
        write_outputs(job_dir, 'edited_transcript', merged, {'edited': True, 'job_id': job_id})
        bundle = write_bundle(job_dir)
        output_dir = job_dir / 'outputs'
        artifacts = [
            {'name': p.name, 'path': str(p.relative_to(settings.jobs_dir.parent)), 'size_bytes': p.stat().st_size, 'kind': p.suffix.lstrip('.')}
            for p in sorted(output_dir.iterdir())
            if p.is_file()
        ]
        artifacts.append({'name': bundle.name, 'path': str(bundle.relative_to(settings.jobs_dir.parent)), 'size_bytes': bundle.stat().st_size, 'kind': 'zip'})
        self.repo.replace_artifacts(job_id, artifacts)
        self.repo.update_job(job_id, outputs_zip=str(bundle.relative_to(settings.jobs_dir.parent)), updated_at=utc_iso(), preview_text=render_plain(merged)[:5000])

    def _run_job(self, job_id: str, options: JobOptions):
        items = self.runtime_items.get(job_id, [])
        job_dir = ensure_dir(settings.jobs_dir / job_id)
        work_dir = ensure_dir(job_dir / 'work')
        downloads_dir = ensure_dir(job_dir / 'downloads')
        artifacts: list[dict] = []
        all_segments: list[dict] = []
        warnings: list[str] = []
        glossary = parse_glossary(options.glossary_text)
        self.repo.update_job(job_id, status='running', progress=0.02, message='Starting', updated_at=utc_iso(), glossary_json=glossary)
        try:
            for idx, item in enumerate(items, start=1):
                if job_id in self.cancelled:
                    self.repo.update_job(job_id, status='cancelled', message='Cancelled', updated_at=utc_iso())
                    return
                if item.source_type == 'url':
                    self.repo.update_job(job_id, message=f'Downloading {item.source_value}', progress=min(0.9, (idx - 1) / max(1, len(items)) * 0.8), updated_at=utc_iso())
                    downloaded = download_url(item.source_value, downloads_dir)
                    item = MediaItem(item.source_type, item.source_value, downloaded, downloaded.stem)
                self.repo.update_job(job_id, message=f'Processing {item.display_name}', progress=min(0.95, idx / max(1, len(items)) * 0.8), updated_at=utc_iso())
                media_path = item.local_path
                if options.preprocess_audio:
                    media_path = preprocess_media(item.local_path, work_dir / item.display_name)
                result = transcribe(media_path, options, settings.domain_prompt_path, glossary)
                segments = result['segments']
                diarization_turns = []
                if options.diarization_enabled:
                    try:
                        diarization_turns = diarize(media_path, settings.hf_token, options.diarization_min_speakers, options.diarization_max_speakers)
                        segments = assign_speakers(segments, diarization_turns)
                    except Exception as exc:
                        warnings.append(f'Diarization skipped for {item.display_name}: {exc}')
                source_prefix = f'{idx:02d}-{safe_name(item.display_name)}'
                for seg in segments:
                    seg['id'] = f"{source_prefix}-{seg['id']}"
                metadata = {
                    'job_id': job_id,
                    'source': item.source_value,
                    'display_name': item.display_name,
                    'engine': result['engine'],
                    'language': result.get('language'),
                    'diarization_turns': diarization_turns,
                    'errors': [*result.get('errors', []), *warnings],
                }
                paths = write_outputs(job_dir, safe_name(item.display_name), segments, metadata)
                for p in paths:
                    artifacts.append({'name': p.name, 'path': str(p.relative_to(settings.jobs_dir.parent)), 'size_bytes': p.stat().st_size, 'kind': p.suffix.lstrip('.')})
                all_segments.extend(segments)
            bundle = write_bundle(job_dir)
            artifacts.append({'name': bundle.name, 'path': str(bundle.relative_to(settings.jobs_dir.parent)), 'size_bytes': bundle.stat().st_size, 'kind': 'zip'})
            self.repo.replace_segments(job_id, all_segments)
            self.repo.replace_artifacts(job_id, artifacts)
            self.repo.update_job(
                job_id,
                status='completed',
                progress=1.0,
                message='Completed',
                updated_at=utc_iso(),
                outputs_zip=str(bundle.relative_to(settings.jobs_dir.parent)),
                preview_text=render_plain(all_segments)[:5000],
                errors_json=warnings,
                metrics_json={
                    'segment_count': len(all_segments),
                    'artifact_count': len(artifacts),
                    'low_confidence_segments': sum(1 for s in all_segments if s.get('low_confidence')),
                    'warnings': len(warnings),
                },
            )
            if getattr(options, 'upload_to_drive', False):
                try:
                    from .drive_upload import upload_bundle_to_drive
                    upload_bundle_to_drive(bundle, job_id)
                except Exception:
                    pass
        except Exception as exc:
            self.repo.update_job(job_id, status='failed', message=f'Failed: {exc}', updated_at=utc_iso(), errors_json=[str(exc)])
        finally:
            self.runtime_items.pop(job_id, None)
