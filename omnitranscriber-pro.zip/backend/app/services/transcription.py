from __future__ import annotations

import gc
import math
import threading
from pathlib import Path
from typing import Callable, TypeVar

from ..schemas import JobOptions
from ..utils import apply_glossary

T = TypeVar('T')
_MODEL_LOCK = threading.Lock()
_MODEL_CACHE: dict[tuple[str, str, str, str], object] = {}


def _normalize_confidence(avg_logprob: float | None) -> float | None:
    if avg_logprob is None:
        return None
    value = 1 / (1 + math.exp(-4 * (avg_logprob + 1)))
    return round(max(0.0, min(1.0, value)), 4)


def _domain_prompt(options: JobOptions, domain_prompt_path: Path) -> str:
    prompt = options.prompt.strip()
    if options.include_domain_prompt and domain_prompt_path.exists():
        extra = domain_prompt_path.read_text(encoding='utf-8').strip()
        prompt = f'{extra}\n{prompt}'.strip()
    return prompt


def _get_cached_model(key: tuple[str, str, str, str], factory: Callable[[], T]) -> T:
    with _MODEL_LOCK:
        if key not in _MODEL_CACHE:
            _MODEL_CACHE.clear()
            gc.collect()
            try:
                import torch

                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
            except Exception:
                pass
            _MODEL_CACHE[key] = factory()
        return _MODEL_CACHE[key]  # type: ignore[return-value]


def _task(options: JobOptions) -> str:
    return 'translate' if options.translation_enabled or options.source_mode == 'translate' else 'transcribe'


def _transcribe_faster_whisper(media_path: Path, options: JobOptions, domain_prompt_path: Path):
    from faster_whisper import WhisperModel

    device = 'auto' if options.device == 'auto' else options.device
    compute_type = 'auto' if options.compute_type == 'auto' else options.compute_type
    model = _get_cached_model(
        ('faster-whisper', options.model, device, compute_type),
        lambda: WhisperModel(options.model, device=device, compute_type=compute_type),
    )
    segments, info = model.transcribe(
        str(media_path),
        language=options.language,
        initial_prompt=_domain_prompt(options, domain_prompt_path) or None,
        vad_filter=options.vad_filter,
        word_timestamps=options.enable_word_timestamps,
        task=_task(options),
    )
    out_segments = []
    for idx, seg in enumerate(segments):
        out_segments.append({
            'id': f'seg-{idx + 1}',
            'start': float(seg.start),
            'end': float(seg.end),
            'text': seg.text.strip(),
            'avg_logprob': getattr(seg, 'avg_logprob', None),
            'words': [
                {
                    'word': getattr(w, 'word', ''),
                    'start': float(getattr(w, 'start', 0) or 0),
                    'end': float(getattr(w, 'end', 0) or 0),
                    'probability': float(getattr(w, 'probability', 0) or 0),
                }
                for w in (getattr(seg, 'words', None) or [])
            ],
        })
    return {'segments': out_segments, 'language': getattr(info, 'language', None)}


def _transcribe_openai_whisper(media_path: Path, options: JobOptions, domain_prompt_path: Path):
    import torch
    import whisper

    device = options.device
    if device == 'auto':
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
    model = _get_cached_model(
        ('openai-whisper', options.model, device, 'default'),
        lambda: whisper.load_model(options.model, device=device),
    )
    result = model.transcribe(
        str(media_path),
        language=options.language,
        initial_prompt=_domain_prompt(options, domain_prompt_path) or None,
        fp16=(device == 'cuda'),
        verbose=False,
        word_timestamps=options.enable_word_timestamps,
        task=_task(options),
    )
    out_segments = []
    for idx, seg in enumerate(result.get('segments', [])):
        out_segments.append({
            'id': f'seg-{idx + 1}',
            'start': float(seg['start']),
            'end': float(seg['end']),
            'text': seg['text'].strip(),
            'avg_logprob': seg.get('avg_logprob'),
            'words': seg.get('words', []),
        })
    return {'segments': out_segments, 'language': result.get('language')}


def _apply_segment_enrichment(segments: list[dict], glossary: dict[str, str], options: JobOptions) -> None:
    try:
        from langdetect import DetectorFactory, detect

        DetectorFactory.seed = 0
    except Exception:
        detect = None

    for seg in segments:
        seg['text'] = apply_glossary(seg['text'], glossary)
        conf = _normalize_confidence(seg.get('avg_logprob'))
        seg['confidence'] = conf
        seg['low_confidence'] = bool(conf is not None and conf < options.confidence_threshold)
        seg.setdefault('speaker', None)
        if detect:
            try:
                seg['language'] = detect(seg['text'])
            except Exception:
                pass


def _translate_from_english(result: dict, target_language: str) -> list[str]:
    model_map = {
        'es': 'Helsinki-NLP/opus-mt-en-es',
        'fr': 'Helsinki-NLP/opus-mt-en-fr',
        'de': 'Helsinki-NLP/opus-mt-en-de',
        'hi': 'Helsinki-NLP/opus-mt-en-hi',
        'zh': 'Helsinki-NLP/opus-mt-en-zh',
        'ja': 'Helsinki-NLP/opus-mt-en-ja',
        'bn': 'Helsinki-NLP/opus-mt-en-bn',
        'pt': 'Helsinki-NLP/opus-mt-en-pt',
        'ru': 'Helsinki-NLP/opus-mt-en-ru',
    }
    model_name = model_map.get(target_language)
    if model_name is None:
        raise RuntimeError(f'No translation model available for target language: {target_language}')

    import torch
    from transformers import MarianMTModel, MarianTokenizer

    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    tokenizer = MarianTokenizer.from_pretrained(model_name)
    model = MarianMTModel.from_pretrained(model_name).to(device)
    texts = [seg['text'] for seg in result['segments']]
    translated_texts: list[str] = []

    try:
        for i in range(0, len(texts), 8):
            batch = texts[i:i + 8]
            inputs = tokenizer(batch, return_tensors='pt', padding=True, truncation=True).to(device)
            with torch.no_grad():
                generated = model.generate(**inputs)
            translated_texts.extend(tokenizer.decode(t, skip_special_tokens=True) for t in generated)
    finally:
        del model
        del tokenizer
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    return translated_texts


def transcribe(media_path: Path, options: JobOptions, domain_prompt_path: Path, glossary: dict[str, str]) -> dict:
    errors = []
    try:
        result = _transcribe_faster_whisper(media_path, options, domain_prompt_path)
        engine = 'faster-whisper'
    except Exception as exc:
        errors.append(f'faster-whisper unavailable: {exc}')
        result = _transcribe_openai_whisper(media_path, options, domain_prompt_path)
        engine = 'openai-whisper'

    _apply_segment_enrichment(result['segments'], glossary, options)

    target_language = options.translation_target_language
    if options.translation_enabled and target_language != 'en':
        try:
            translated_texts = _translate_from_english(result, target_language)
            for seg, translated in zip(result['segments'], translated_texts):
                seg['text'] = translated.strip()
                seg['language'] = target_language
            result['language'] = target_language
        except Exception as exc:
            errors.append(f'translation_error: {exc}')

    result['engine'] = engine
    result['errors'] = errors
    return result
