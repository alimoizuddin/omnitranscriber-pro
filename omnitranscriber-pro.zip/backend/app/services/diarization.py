from __future__ import annotations

from pathlib import Path


def diarize(media_path: Path, hf_token: str | None = None, min_speakers: int | None = None, max_speakers: int | None = None) -> list[dict]:
    if not hf_token:
        raise RuntimeError('Diarization requires a Hugging Face token for pyannote models.')
    from pyannote.audio import Pipeline

    pipeline = Pipeline.from_pretrained('pyannote/speaker-diarization-3.1', use_auth_token=hf_token)
    diarization = pipeline(str(media_path), min_speakers=min_speakers, max_speakers=max_speakers)
    turns = []
    for turn, _, speaker in diarization.itertracks(yield_label=True):
        turns.append({'start': float(turn.start), 'end': float(turn.end), 'speaker': speaker})
    return turns


def assign_speakers(segments: list[dict], diarization_turns: list[dict]) -> list[dict]:
    for seg in segments:
        best = None
        best_overlap = 0.0
        for turn in diarization_turns:
            start = max(seg['start'], turn['start'])
            end = min(seg['end'], turn['end'])
            overlap = max(0.0, end - start)
            if overlap > best_overlap:
                best_overlap = overlap
                best = turn['speaker']
        seg['speaker'] = best
    return segments
