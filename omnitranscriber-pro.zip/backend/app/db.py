from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any

from .config import settings


class Database:
    def __init__(self, path: Path):
        self.path = path
        self._init()

    def connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        return conn

    def _init(self) -> None:
        conn = self.connect()
        with conn:
            conn.executescript(
                '''
                CREATE TABLE IF NOT EXISTS jobs (
                    job_id TEXT PRIMARY KEY,
                    title TEXT NOT NULL,
                    status TEXT NOT NULL,
                    progress REAL NOT NULL DEFAULT 0,
                    message TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    options_json TEXT NOT NULL,
                    source_count INTEGER NOT NULL DEFAULT 0,
                    outputs_zip TEXT,
                    preview_text TEXT NOT NULL DEFAULT '',
                    errors_json TEXT NOT NULL DEFAULT '[]',
                    metrics_json TEXT NOT NULL DEFAULT '{}',
                    glossary_json TEXT NOT NULL DEFAULT '{}'
                );
                CREATE TABLE IF NOT EXISTS segments (
                    id TEXT PRIMARY KEY,
                    job_id TEXT NOT NULL,
                    start REAL NOT NULL,
                    end REAL NOT NULL,
                    text TEXT NOT NULL,
                    speaker TEXT,
                    avg_logprob REAL,
                    confidence REAL,
                    low_confidence INTEGER NOT NULL DEFAULT 0,
                    words_json TEXT NOT NULL DEFAULT '[]',
                    language TEXT,
                    FOREIGN KEY(job_id) REFERENCES jobs(job_id)
                );
                CREATE TABLE IF NOT EXISTS artifacts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    job_id TEXT NOT NULL,
                    name TEXT NOT NULL,
                    path TEXT NOT NULL,
                    size_bytes INTEGER NOT NULL,
                    kind TEXT NOT NULL,
                    FOREIGN KEY(job_id) REFERENCES jobs(job_id)
                );
                CREATE INDEX IF NOT EXISTS idx_segments_job_id ON segments(job_id);
                CREATE INDEX IF NOT EXISTS idx_artifacts_job_id ON artifacts(job_id);
                '''
            )
            self._ensure_column(conn, 'segments', 'language', 'TEXT')
        conn.close()

    def _ensure_column(self, conn: sqlite3.Connection, table: str, column: str, definition: str) -> None:
        columns = {row['name'] for row in conn.execute(f'PRAGMA table_info({table})').fetchall()}
        if column not in columns:
            conn.execute(f'ALTER TABLE {table} ADD COLUMN {column} {definition}')

    def execute(self, sql: str, params: tuple = ()) -> None:
        conn = self.connect()
        with conn:
            conn.execute(sql, params)
        conn.close()

    def executemany(self, sql: str, rows: list[tuple]) -> None:
        conn = self.connect()
        with conn:
            conn.executemany(sql, rows)
        conn.close()

    def query(self, sql: str, params: tuple = ()) -> list[sqlite3.Row]:
        conn = self.connect()
        rows = conn.execute(sql, params).fetchall()
        conn.close()
        return rows


_db = Database(settings.sqlite_path)

def get_db() -> Database:
    return _db
