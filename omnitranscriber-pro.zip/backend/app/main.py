from __future__ import annotations

import shutil
from pathlib import Path
from typing import Annotated
from urllib.parse import urlparse

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles

from .config import settings
from .schemas import JobOptions, SegmentPatch, UrlIngestRequest
from .services.jobs import JobManager, MediaItem
from .services.media import has_binary
from .utils import MEDIA_EXTS, safe_name, utc_iso

app = FastAPI(title=settings.app_name, version='2.0.0')
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allow_origins,
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)
manager = JobManager()
BACKEND_DIR = Path(__file__).resolve().parents[1]
PROJECT_DIR = BACKEND_DIR.parent
FRONTEND_DIR = PROJECT_DIR / 'frontend'
app.mount('/assets', StaticFiles(directory=str(FRONTEND_DIR)), name='assets')


def _unique_path(path: Path) -> Path:
    if not path.exists():
        return path
    for idx in range(2, 1000):
        candidate = path.with_name(f'{path.stem}-{idx}{path.suffix}')
        if not candidate.exists():
            return candidate
    raise HTTPException(status_code=400, detail='Too many files with the same name in one upload')


@app.get('/', response_class=HTMLResponse)
def index():
    return HTMLResponse((FRONTEND_DIR / 'index.html').read_text(encoding='utf-8'))


@app.get('/api/health')
def health():
    return {'ok': True, 'app_name': settings.app_name, 'version': app.version}


@app.get('/api/system')
def system_status():
    cuda = False
    gpu_name = ''
    try:
        import torch

        cuda = bool(torch.cuda.is_available())
        gpu_name = torch.cuda.get_device_name(0) if cuda else ''
    except Exception:
        pass
    return {
        'ffmpeg': has_binary('ffmpeg'),
        'yt_dlp': has_binary('yt-dlp'),
        'cuda': cuda,
        'gpu_name': gpu_name,
        'data_dir': str(settings.data_dir),
    }


@app.get('/api/config')
def config():
    prompt = settings.domain_prompt_path.read_text(encoding='utf-8') if settings.domain_prompt_path.exists() else ''
    return {
        'app_name': settings.app_name,
        'models': ['tiny', 'base', 'small', 'medium', 'large-v3', 'distil-large-v3'],
        'prompt': prompt,
        'features': {
            'diarization_requires_hf_token': True,
            'url_ingest': True,
            'glossary': True,
            'editor': True,
        },
    }


@app.get('/api/jobs')
def list_jobs():
    return [job.model_dump() for job in manager.list_jobs()]


@app.get('/api/jobs/{job_id}')
def get_job(job_id: str):
    try:
        return manager.get(job_id).model_dump()
    except KeyError as exc:
        raise HTTPException(status_code=404, detail='Job not found') from exc


@app.get('/api/download/{rel_path:path}')
def download(rel_path: str):
    data_root = settings.data_dir.resolve()
    path = (data_root / rel_path).resolve()
    try:
        path.relative_to(data_root)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail='Invalid download path') from exc
    if not path.exists() or not path.is_file():
        raise HTTPException(status_code=404, detail='File not found')
    return FileResponse(path, filename=path.name)


@app.post('/api/jobs/upload')
async def upload_job(files: list[UploadFile] = File(...), options_json: Annotated[str, Form()] = '{}'):
    options = JobOptions.model_validate_json(options_json)
    batch_root = settings.uploads_dir / utc_iso().replace(':', '-')
    batch_root.mkdir(parents=True, exist_ok=True)
    items = []
    for upload in files:
        suffix = Path(upload.filename or '').suffix.lower()
        if suffix not in MEDIA_EXTS:
            raise HTTPException(status_code=400, detail=f'Unsupported file type: {upload.filename}')
        file_name = safe_name(Path(upload.filename or 'upload').stem) + suffix
        dest = _unique_path(batch_root / file_name)
        with dest.open('wb') as f:
            shutil.copyfileobj(upload.file, f)
        items.append(MediaItem('upload', upload.filename or dest.name, dest, dest.stem))
    return manager.create_upload_job(items, options).model_dump()


@app.post('/api/jobs/url')
def create_url_job(request: UrlIngestRequest):
    urls = [u.strip() for u in request.urls if u.strip()]
    if not urls:
        raise HTTPException(status_code=400, detail='No URLs')
    for url in urls:
        parsed = urlparse(url)
        if parsed.scheme not in {'http', 'https'} or not parsed.netloc:
            raise HTTPException(status_code=400, detail=f'Use a full http(s) link: {url}')
    return manager.create_url_job(urls, request.options).model_dump()


@app.post('/api/jobs/{job_id}/cancel')
def cancel_job(job_id: str):
    manager.cancel(job_id)
    return {'ok': True}


@app.post('/api/jobs/{job_id}/segments')
def save_segments(job_id: str, patches: list[SegmentPatch]):
    manager.save_segments(job_id, [p.model_dump() for p in patches])
    return {'ok': True}


@app.post('/api/domain-prompt')
def save_prompt(payload: dict):
    settings.domain_prompt_path.write_text(str(payload.get('prompt', '')), encoding='utf-8')
    return {'ok': True}


if __name__ == '__main__':
    import uvicorn
    uvicorn.run('app.main:app', host=settings.host, port=settings.port, reload=False)
