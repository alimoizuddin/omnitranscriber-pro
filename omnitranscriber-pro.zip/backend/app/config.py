from __future__ import annotations

from pathlib import Path
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix='OT_', env_file='.env', extra='ignore')

    app_name: str = 'OmniTranscriber Pro'
    host: str = '127.0.0.1'
    port: int = 8000
    data_dir: Path = Field(default_factory=lambda: Path(__file__).resolve().parents[2] / 'data')
    uploads_subdir: str = 'uploads'
    jobs_subdir: str = 'jobs'
    sqlite_name: str = 'omnitranscriber.db'
    max_workers: int = 1
    allow_origins: list[str] = ['*']
    domain_prompt_path: Path = Field(default_factory=lambda: Path(__file__).resolve().parents[2] / 'domain_prompt.txt')
    hf_token: str | None = None

    @property
    def uploads_dir(self) -> Path:
        return self.data_dir / self.uploads_subdir

    @property
    def jobs_dir(self) -> Path:
        return self.data_dir / self.jobs_subdir

    @property
    def sqlite_path(self) -> Path:
        return self.data_dir / self.sqlite_name

    def ensure(self) -> None:
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.uploads_dir.mkdir(parents=True, exist_ok=True)
        self.jobs_dir.mkdir(parents=True, exist_ok=True)
        self.domain_prompt_path.parent.mkdir(parents=True, exist_ok=True)
        if not self.domain_prompt_path.exists():
            self.domain_prompt_path.write_text('', encoding='utf-8')


settings = Settings()
settings.ensure()
