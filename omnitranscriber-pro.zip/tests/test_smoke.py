from pathlib import Path

from fastapi.testclient import TestClient

from app.main import app
from app.services.exporter import render_markdown, render_plain
from app.utils import parse_glossary, apply_glossary


def test_root():
    client = TestClient(app)
    res = client.get('/')
    assert res.status_code == 200
    assert 'OmniTranscriber Pro' in res.text


def test_health():
    client = TestClient(app)
    res = client.get('/api/health')
    assert res.status_code == 200
    assert res.json()['ok'] is True


def test_download_blocks_path_traversal():
    client = TestClient(app)
    res = client.get('/api/download/..%2F..%2FREADME.md')
    assert res.status_code == 400


def test_glossary():
    g = parse_glossary('spivak => Gayatri Chakravorty Spivak')
    assert apply_glossary('Today spivak appears here.', g) == 'Today Gayatri Chakravorty Spivak appears here.'


def test_transcript_exports_include_timestamps():
    segments = [{'start': 1.25, 'end': 3.5, 'text': 'Hello world.', 'speaker': 'Ali'}]

    assert render_plain(segments) == '[00:00:01.250 --> 00:00:03.500] Ali: Hello world.'
    assert '`00:00:01.250 --> 00:00:03.500`' in render_markdown(segments)
