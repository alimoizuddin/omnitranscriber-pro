const state = {
  config: null,
  jobs: [],
  activeJob: null,
  draftSegments: [],
  recordingBlob: null,
  recorder: null,
  recorderStream: null,
  recorderChunks: [],
};

async function requestJSON(url, options = {}) {
  const res = await fetch(url, options);
  const text = await res.text();
  let payload = null;
  if (text) {
    try {
      payload = JSON.parse(text);
    } catch {
      payload = text;
    }
  }
  if (!res.ok) {
    const detail = payload?.detail || payload || 'The request failed.';
    throw new Error(Array.isArray(detail) ? detail.map(x => x.msg || x).join(', ') : String(detail));
  }
  return payload;
}

function showNotice(message, type = 'info') {
  const notice = document.getElementById('notice');
  notice.textContent = message;
  notice.className = `notice ${type === 'error' ? 'error' : ''}`;
  notice.hidden = false;
  clearTimeout(showNotice.timer);
  showNotice.timer = setTimeout(() => {
    notice.hidden = true;
  }, 4500);
}

function formatPercent(value) {
  return `${Math.round((Number(value) || 0) * 100)}%`;
}

function downloadHref(path) {
  return `/api/download/${encodeURI(path).replace(/#/g, '%23')}`;
}

function optionsFromForm() {
  return {
    model: document.getElementById('model').value,
    language: document.getElementById('language').value.trim() || null,
    prompt: document.getElementById('prompt').value,
    glossary_text: document.getElementById('glossary').value,
    include_domain_prompt: document.getElementById('includeDomainPrompt').checked,
    preprocess_audio: document.getElementById('preprocessAudio').checked,
    vad_filter: document.getElementById('vadFilter').checked,
    diarization_enabled: document.getElementById('diarizationEnabled').checked,
    chunk_minutes: Number(document.getElementById('chunkMinutes').value || 20),
    confidence_threshold: Number(document.getElementById('confidenceThreshold').value || 0.45),
    translation_enabled: document.getElementById('translationEnabled').checked,
    translation_target_language: document.getElementById('translationTargetLanguage').value || 'en',
    upload_to_drive: document.getElementById('saveToDrive').checked,
  };
}

function pill(status) {
  const span = document.createElement('span');
  span.className = `pill ${status}`;
  span.textContent = status || 'unknown';
  return span;
}

function renderJobs() {
  const el = document.getElementById('jobList');
  el.innerHTML = '';

  if (!state.jobs.length) {
    const empty = document.createElement('div');
    empty.className = 'job-item';
    empty.textContent = 'No jobs yet';
    el.appendChild(empty);
    return;
  }

  state.jobs.forEach(job => {
    const item = document.createElement('button');
    item.type = 'button';
    item.className = `job-item ${state.activeJob?.job_id === job.job_id ? 'active' : ''}`;

    const title = document.createElement('span');
    title.className = 'job-title';
    title.textContent = job.title;

    const meta = document.createElement('div');
    meta.className = 'job-meta-line';
    meta.textContent = `${job.status} - ${formatPercent(job.progress)} - ${job.source_count} source(s)`;

    item.append(title, meta);
    item.addEventListener('click', () => selectJob(job.job_id));
    el.appendChild(item);
  });
}

function renderArtifactLinks(job) {
  const art = document.getElementById('artifactLinks');
  art.innerHTML = '';
  const seen = new Set();

  (job.artifacts || []).forEach(a => {
    seen.add(a.path);
    const link = document.createElement('a');
    link.href = downloadHref(a.path);
    link.textContent = `${a.name} (${a.kind})`;
    link.target = '_blank';
    art.appendChild(link);
  });

  if (job.outputs_zip && !seen.has(job.outputs_zip)) {
    const zipLink = document.createElement('a');
    zipLink.href = downloadHref(job.outputs_zip);
    zipLink.textContent = 'Download everything as one ZIP';
    zipLink.target = '_blank';
    art.appendChild(zipLink);
  }
}

function renderSegments(job) {
  const editorEmpty = document.getElementById('editorEmpty');
  const segmentTable = document.getElementById('segmentTable');
  segmentTable.innerHTML = '';

  if (!job.segments?.length) {
    editorEmpty.style.display = 'block';
    return;
  }

  editorEmpty.style.display = 'none';
  state.draftSegments = JSON.parse(JSON.stringify(job.segments));

  state.draftSegments.forEach((seg, idx) => {
    const row = document.createElement('div');
    row.className = `segment-row ${seg.low_confidence ? 'low' : ''}`;

    const timing = document.createElement('div');
    const id = document.createElement('div');
    id.className = 'segment-id';
    id.textContent = seg.id;
    const time = document.createElement('div');
    time.className = 'small';
    time.textContent = `${Number(seg.start).toFixed(2)} to ${Number(seg.end).toFixed(2)}`;
    timing.append(id, time);

    const speaker = document.createElement('input');
    speaker.value = seg.speaker || '';
    speaker.placeholder = 'Speaker';
    speaker.addEventListener('input', e => {
      state.draftSegments[idx].speaker = e.target.value;
    });

    const text = document.createElement('textarea');
    text.rows = 3;
    text.value = seg.text || '';
    text.addEventListener('input', e => {
      state.draftSegments[idx].text = e.target.value;
    });

    const meta = document.createElement('div');
    meta.className = 'small';
    meta.textContent = `Confidence: ${seg.confidence ?? 'n/a'}\n${seg.low_confidence ? 'Needs review' : 'OK'}\nLanguage: ${seg.language || job.language || 'auto'}`;

    row.append(timing, speaker, text, meta);
    segmentTable.appendChild(row);
  });
}

function renderActiveJob() {
  const job = state.activeJob;
  const saveEdits = document.getElementById('saveEdits');
  const jobMeta = document.getElementById('jobMeta');
  const jobStateLabel = document.getElementById('jobStateLabel');
  document.getElementById('artifactLinks').innerHTML = '';
  document.getElementById('segmentTable').innerHTML = '';
  document.getElementById('editorEmpty').style.display = 'block';

  saveEdits.disabled = !job || job.status !== 'completed';

  if (!job) {
    jobStateLabel.textContent = 'No job selected';
    jobMeta.className = 'empty-state';
    jobMeta.textContent = 'Choose a job from the left side.';
    return;
  }

  jobStateLabel.textContent = `${job.status} - ${formatPercent(job.progress)}`;
  jobMeta.className = '';
  jobMeta.innerHTML = '';
  const title = document.createElement('div');
  title.className = 'segment-id';
  title.textContent = job.title;
  const details = document.createElement('div');
  details.className = 'small';
  details.textContent = `${job.source_count} source(s) - ${job.message || 'No message'}`;
  const low = document.createElement('div');
  low.className = 'small';
  low.textContent = `Low-confidence segments: ${(job.metrics && job.metrics.low_confidence_segments) || 0}`;
  jobMeta.append(title, pill(job.status), details, low);

  if (job.errors?.length) {
    const errors = document.createElement('div');
    errors.className = 'small';
    errors.textContent = `Notes: ${job.errors.join(' | ')}`;
    jobMeta.appendChild(errors);
  }

  renderArtifactLinks(job);
  renderSegments(job);
}

async function refreshJobs() {
  state.jobs = await requestJSON('/api/jobs');
  renderJobs();
  if (state.activeJob) {
    const fresh = state.jobs.find(j => j.job_id === state.activeJob.job_id);
    if (fresh) {
      await selectJob(fresh.job_id, false);
    }
  }
}

async function selectJob(jobId, rerender = true) {
  state.activeJob = await requestJSON(`/api/jobs/${jobId}`);
  if (rerender) {
    renderJobs();
  }
  renderActiveJob();
}

async function renderSystemStatus() {
  const el = document.getElementById('systemStatus');
  try {
    const status = await requestJSON('/api/system');
    const gpu = status.cuda ? `GPU: ${status.gpu_name || 'available'}` : 'GPU: not detected';
    el.innerHTML = `
      <div>FFmpeg: ${status.ffmpeg ? 'ready' : 'missing'}</div>
      <div>Link downloads: ${status.yt_dlp ? 'ready' : 'missing'}</div>
      <div>${gpu}</div>
    `;
  } catch (err) {
    el.textContent = `System check failed: ${err.message}`;
  }
}

async function startUploadJob(event) {
  event.preventDefault();
  const files = [...document.getElementById('files').files];
  if (!files.length && !state.recordingBlob) {
    showNotice('Choose a file or record audio first.', 'error');
    return;
  }

  const fd = new FormData();
  files.forEach(file => fd.append('files', file));
  if (state.recordingBlob) {
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    fd.append('files', state.recordingBlob, `recording-${stamp}.webm`);
  }
  fd.append('options_json', JSON.stringify(optionsFromForm()));

  const job = await requestJSON('/api/jobs/upload', { method: 'POST', body: fd });
  state.activeJob = job;
  await refreshJobs();
  await selectJob(job.job_id);
  showNotice('File job started.');
}

async function startUrlJob(event) {
  event.preventDefault();
  const urls = document.getElementById('urls').value.split('\n').map(x => x.trim()).filter(Boolean);
  if (!urls.length) {
    showNotice('Paste at least one link.', 'error');
    return;
  }

  const job = await requestJSON('/api/jobs/url', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ urls, options: optionsFromForm() }),
  });
  state.activeJob = job;
  await refreshJobs();
  await selectJob(job.job_id);
  showNotice('Link job started.');
}

async function toggleRecording() {
  const button = document.getElementById('recordToggle');
  const status = document.getElementById('recordStatus');

  if (state.recorder && state.recorder.state === 'recording') {
    state.recorder.stop();
    button.textContent = 'Record microphone';
    status.textContent = 'Saving recording...';
    return;
  }

  try {
    state.recorderStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    state.recorderChunks = [];
    state.recorder = new MediaRecorder(state.recorderStream);
    state.recorder.addEventListener('dataavailable', event => {
      if (event.data.size > 0) state.recorderChunks.push(event.data);
    });
    state.recorder.addEventListener('stop', () => {
      state.recordingBlob = new Blob(state.recorderChunks, { type: 'audio/webm' });
      const preview = document.getElementById('recordingPreview');
      preview.src = URL.createObjectURL(state.recordingBlob);
      preview.hidden = false;
      status.textContent = 'Recording added to next file job';
      state.recorderStream?.getTracks().forEach(track => track.stop());
      state.recorderStream = null;
    });
    state.recorder.start();
    button.textContent = 'Stop recording';
    status.textContent = 'Recording...';
  } catch (err) {
    showNotice(`Microphone could not start: ${err.message}`, 'error');
  }
}

async function init() {
  state.config = await requestJSON('/api/config');
  const modelSelect = document.getElementById('model');
  state.config.models.forEach(model => {
    const opt = document.createElement('option');
    opt.value = model;
    opt.textContent = model;
    modelSelect.appendChild(opt);
  });
  modelSelect.value = state.config.models.includes('large-v3') ? 'large-v3' : state.config.models[0];
  document.getElementById('domainPrompt').value = state.config.prompt || '';

  if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) {
    document.getElementById('recordToggle').disabled = true;
    document.getElementById('recordStatus').textContent = 'Microphone recording is unavailable in this browser';
  }

  await renderSystemStatus();
  await refreshJobs();
  setInterval(refreshJobs, 4000);
  setInterval(renderSystemStatus, 30000);
}

document.getElementById('uploadForm').addEventListener('submit', event => {
  startUploadJob(event).catch(err => showNotice(err.message, 'error'));
});

document.getElementById('urlForm').addEventListener('submit', event => {
  startUrlJob(event).catch(err => showNotice(err.message, 'error'));
});

document.getElementById('savePrompt').addEventListener('click', async () => {
  try {
    await requestJSON('/api/domain-prompt', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt: document.getElementById('domainPrompt').value }),
    });
    showNotice('Prompt saved.');
  } catch (err) {
    showNotice(err.message, 'error');
  }
});

document.getElementById('refreshJobs').addEventListener('click', () => {
  refreshJobs().catch(err => showNotice(err.message, 'error'));
});

document.getElementById('recordToggle').addEventListener('click', toggleRecording);

document.getElementById('saveEdits').addEventListener('click', async () => {
  if (!state.activeJob) return;
  try {
    const payload = state.draftSegments.map(seg => ({ id: seg.id, text: seg.text, speaker: seg.speaker || null }));
    await requestJSON(`/api/jobs/${state.activeJob.job_id}/segments`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    await selectJob(state.activeJob.job_id);
    showNotice('Edits saved.');
  } catch (err) {
    showNotice(err.message, 'error');
  }
});

init().catch(err => showNotice(err.message, 'error'));
