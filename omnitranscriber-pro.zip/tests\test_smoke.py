from pathlib import Path

from fastapi.testclient import TestClient

from app.main import app
from app.utils import parse_glossary, apply_glossary


def test_root():
    client = TestClient(app)
    res = client.get('/')
    assert res.status_code == 200
    assert 'OmniTranscriber Pro' in res.text


def test_health():
    client = TestClient(app)
    res = client.get('/api/health')
    assert res.status_code == 200
    assert res.json()['ok'] is True


def test_download_blocks_path_traversal():
    client = TestClient(app)
    res = client.get('/api/download/..%2F..%2FREADME.md')
    assert res.status_code == 400


def test_glossary():
    g = parse_glossary('spivak => Gayatri Chakravorty Spivak')
    assert apply_glossary('Today spivak appears here.', g) == 'Today Gayatri Chakravorty Spivak appears here.'
