# OmniTranscriber Pro

OmniTranscriber Pro is a full-stack transcription app with a browser frontend, FastAPI backend, background job processing, SQLite history, Google Colab GPU support, URL ingest, microphone recording, transcript editing, and export bundles.

For non-technical use, start with `guide.txt`.

## What Is Included

- `frontend/` - the browser app.
- `backend/` - the FastAPI app, job manager, database, transcription services, exports, and Dockerfile.
- `backend/requirements-optional.txt` - optional packages for speaker diarization and extra offline translation.
- `OmniTranscriber_Colab_GPU.ipynb` - launches the same full-stack app on Google Colab GPU.
- `run_windows.bat` - one-file Windows launcher.
- `run_mac_linux.sh` - Mac/Linux launcher.
- `guide.txt` - plain-language instructions for end users.
- `tests/` - smoke tests for startup and core glossary behavior.

## Main Features

- File uploads, browser microphone recording, and URL jobs.
- Whisper transcription through faster-whisper with OpenAI Whisper fallback.
- GPU-friendly default of one worker to reduce Colab out-of-memory failures.
- Reused in-process model cache for faster repeated jobs with the same model.
- Optional speaker diarization with a Hugging Face token.
- Optional translation to English through Whisper, and selected other languages through MarianMT.
- Glossary corrections and saved domain prompt support.
- TXT, Markdown, SRT, VTT, JSON, and ZIP exports.
- Editable transcript segments after a job finishes.
- Safer download handling and unique segment IDs across batch jobs.

## Local Development

Use Python 3.10 or 3.11.

```bash
cd backend
python -m pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:8000`.

Install optional advanced packages only when needed:

```bash
python -m pip install -r requirements-optional.txt
```

## Google Colab GPU

1. In Colab, choose `Runtime > Change runtime type > GPU`.
2. Upload and run `OmniTranscriber_Colab_GPU.ipynb`.
3. Upload the ZIP bundle when the notebook asks.
4. The notebook installs dependencies and opens the full browser app through Colab's port proxy.

The default Colab install focuses on reliable transcription. The notebook also includes an optional advanced-features cell for speaker diarization and extra offline translation models.

To save result ZIP files to Google Drive in Colab, run the optional Drive mount cell before starting jobs and tick `Save bundle to Google Drive when available` in the app.

## Environment Options

- `OT_HOST` - host to bind, default `127.0.0.1`.
- `OT_PORT` - port to bind, default `8000`.
- `OT_DATA_DIR` - custom data folder.
- `OT_MAX_WORKERS` - number of background workers, default `1`.
- `OT_HF_TOKEN` - Hugging Face token for pyannote speaker diarization.
- `OT_GOOGLE_DRIVE_DIR` - local folder where completed ZIP bundles should be copied when Drive saving is enabled.

## Docker

Build from the project root:

```bash
docker build -f backend/Dockerfile -t omnitranscriber-pro .
docker run --rm -p 8000:8000 omnitranscriber-pro
```

Then open `http://127.0.0.1:8000`.

## Tests

```bash
pytest
```

The tests verify that the backend imports from the project root, the app serves the UI, the health endpoint works, and glossary replacement behaves correctly.
